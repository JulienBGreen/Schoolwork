
public class Ingredient {
	public String name;
	public String amount;
	public String measurementType;
	
}
